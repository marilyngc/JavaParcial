/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.zoologico;

/**
 *
 * @author Marilyn
 */
public class Reptil extends Animal {

    private String tipoEscama;
    private String regulacionTemperatura;

    
    public Reptil(){}
    
    public Reptil(String tipoEscama, String regulacionTemperatura, String nombre, int edad, double peso, TipoDieta tipoDieta) {
        super(nombre, edad, peso, tipoDieta);
        this.tipoEscama = tipoEscama;
        this.regulacionTemperatura = regulacionTemperatura;
    }
    
    
    @Override
    public void mostrarInformacion() {
      System.out.println(this.toString() + ", Tipo de escama: " + tipoEscama + ", Regulación de temperatura: " + regulacionTemperatura);
    }
    
}
