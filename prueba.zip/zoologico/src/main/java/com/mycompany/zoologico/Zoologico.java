/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.zoologico;

import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author Marilyn
 */
public class Zoologico {
    private List<Animal> animales;

    public Zoologico() {
        animales = new ArrayList<>();
    }
    
    
    public void agregarAnimal(Animal animal){
        if(animales.contains(animal)){
            throw new AnimalRepetidoException();
        }
        
        if(animal == null){
            throw new NullPointerException();
        }
        
        animales.add(animal);
    }
    
    public void mostrarInformacion(){
        for(Animal animal : animales){
            animal.mostrarInformacion();
        }
    }
    
    public void vacunarAnimal(Animal animal) throws AnimalNoVacunableException{
        for(Animal a: animales){
            if(a instanceof Vacunar){
                ((Vacunar) a).Vacunar();
            }
            throw new AnimalNoVacunableException("El animal " + animal.getNombre() + "No es vacunable");
        }
    }
}
