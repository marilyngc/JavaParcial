/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.zoologico;

import java.util.ArrayList;

/**
 *
 * @author Marilyn
 */
public class Ave  extends Animal implements Vacunar {
    private boolean vacunado;
    private double envergaduraAlas;
    
    public Ave(){
        
    }
    public Ave( double envergaduraAlas, String nombre, int edad, double peso, TipoDieta tipoDieta) {
        super(nombre, edad, peso, tipoDieta);
        this.vacunado = false;
        this.envergaduraAlas = envergaduraAlas;
    }
    
   
    
   
    @Override
    public void Vacunar() {
        this.vacunado = true;
    }

    @Override
    public void mostrarInformacion() {
         System.out.println(this.toString() + ", Envergadura de alas: " + envergaduraAlas + "m, Vacunado: " + (vacunado ? "Sí" : "No"));
    }

    @Override
    public String toString() {
        return "Aves{" + "vacunado=" + vacunado + '}';
    }
    
    
    
}
