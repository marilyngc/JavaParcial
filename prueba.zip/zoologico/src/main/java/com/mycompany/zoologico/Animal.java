/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.zoologico;

import java.util.ArrayList;
import java.util.Objects;

/**
 *
 * @author Marilyn
 */
public abstract class Animal {
    protected String nombre;
    protected int edad;
    protected double peso;
    protected TipoDieta tipoDieta;

    public Animal(){}
    
    public Animal(String nombre, int edad, double peso, TipoDieta tipoDieta) {
        this.nombre = nombre;
        this.edad = edad;
        this.peso = peso;
        this.tipoDieta = tipoDieta;
    }

    @Override
    public String toString() {
        return "Animal{" + "nombre=" + nombre + ", edad=" + edad + ", peso=" + peso + ", tipoDieta=" + tipoDieta + '}';
    }
    
    
    
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        Animal animal = (Animal) obj;
        return edad == animal.edad && nombre.equals(animal.nombre);
    }

    @Override
    public int hashCode() {
        
        return Objects.hash(edad,nombre);
    }

    public String getNombre() {
        return nombre;
    }

   

    
    public abstract void mostrarInformacion();
}
