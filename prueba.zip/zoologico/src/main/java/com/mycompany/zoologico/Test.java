/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package com.mycompany.zoologico;

/**
 *
 * @author Marilyn
 */
public class Test {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        
        Zoologico zoloogico = new Zoologico();
        try {
            Mamifero leon = new Mamifero("León", 8, 190.5, TipoDieta.CARNIVORO);
            Ave aguila = new Ave(2.5, "Águila Real", 5, 7.8, TipoDieta.CARNIVORO);
            Reptil serpiente = new Reptil("Dura", "Ectotérmica", "Serpiente", 12, 500.0, TipoDieta.CARNIVORO);

            
           zoloogico.agregarAnimal(leon);
            zoloogico.agregarAnimal(aguila);
            zoloogico.agregarAnimal(serpiente);
            /**
            zoloogico.agregarAnimal(serpiente);
           */

            try{
                 zoloogico.vacunarAnimal(aguila);
                 zoloogico.vacunarAnimal(serpiente);
            }catch(AnimalNoVacunableException e){
                System.out.println(e);
            }
        }catch(AnimalRepetidoException e){
            System.out.println(e);
        }catch(NullPointerException e){
            System.out.println(e);
        }
    }

}
