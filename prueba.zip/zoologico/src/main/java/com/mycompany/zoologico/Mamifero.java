/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.zoologico;

import java.util.ArrayList;

/**
 *
 * @author Marilyn
 */
public class Mamifero extends Animal implements Vacunar {
    private boolean vacunado;

    public Mamifero(){
        
    }
    public Mamifero( String nombre, int edad, double peso, TipoDieta tipoDieta) {
        super(nombre, edad, peso, tipoDieta);
        this.vacunado = false;
    }
    
   
    
    
    

    @Override
    public void Vacunar() {
       this.vacunado = true;
    }

    @Override
    public void mostrarInformacion() {
        System.out.println(this.toString() + ", Vacunado: " + (vacunado ? "Sí" : "No"));
    }
    
}
