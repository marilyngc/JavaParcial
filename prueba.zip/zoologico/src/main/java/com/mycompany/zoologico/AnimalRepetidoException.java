/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.zoologico;

/**
 *
 * @author Marilyn
 */
public class AnimalRepetidoException extends RuntimeException {
    private static final String MENSAJE = "El animal ya está incluido";

    public AnimalRepetidoException() {
        super(MENSAJE);
    }
    
    
}
